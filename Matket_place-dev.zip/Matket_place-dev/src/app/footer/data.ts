export const footerData =[
    {
        link: "/",
        title: "Объявления"
    },
    {
        link: "/help",
        title: "Помощь"
    },
    {
        link: "/contact-administration",
        title: "Связаться с администрацией"
    },
    {
        link: "/privacy-policy",
        title: "Политика конфиденциальностти"
    },
];