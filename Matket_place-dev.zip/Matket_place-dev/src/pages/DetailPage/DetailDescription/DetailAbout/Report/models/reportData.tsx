
export const reportData = [
    {name: "wrong", rusName: "Неверная рубрика"},
    {name: "forbidden", rusName: "Запрещенный товар/услуги"},
    {name: "not_relevant", rusName: "Обьявление не актуально"},
    {name: "wrong_address", rusName: "Неверный адрес"}
];