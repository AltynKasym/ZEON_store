
export const transactionTheme = ["Тип рекламы", "Объявление", "Дата", "Сумма"];

export const transactionData = [
    {
        typeAd: "Выделение цветом",
        adverts: "Продаю ваз2107",
        data: "24.02.2020",
        sum: "700₸"
    },
    {
        typeAd: "Выделение цветом",
        adverts: "Продаю ваз2107",
        data: "24.02.2020",
        sum: "7000₸"
    },
    {
        typeAd: "Выделение цветом",
        adverts: "Продаю ваз2107",
        data: "24.02.2020",
        sum: "7300₸"
    },
];