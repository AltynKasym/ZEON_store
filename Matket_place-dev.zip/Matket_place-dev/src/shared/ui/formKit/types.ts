export interface FormRef {
    resetForm: () => void;
}