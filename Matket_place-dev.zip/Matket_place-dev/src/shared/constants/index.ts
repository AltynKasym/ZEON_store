const LS_USER_KEY = "currentUser";


export const Constants = {
    LS_USER_KEY
};
