export interface DeleteAdvert {
    advertId: number;
}


export type TagsType = "Adverts";
