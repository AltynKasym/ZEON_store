export {newAdvertsSlice} from "./newAdverts";
export {favoritesInfoSlice, fetchFavoriteIds} from "./favoritesInfo";